let age=25;
if(age>=18)
{
    console.log("you can vote")
}
else {
    console.log("you can't vote")
}