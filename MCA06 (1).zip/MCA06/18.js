// let total=0;
// let num=10;

for(let i=1; i<=10; i++){
    // total=total+i
    if(i==4){
        break;
    }
    console.log(i);
}
