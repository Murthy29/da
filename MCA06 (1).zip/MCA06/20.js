let mixed = [1,2,3,"mango","apple","orange"]
console.log(mixed[5]);