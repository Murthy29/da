let num=100;
let total=0;
let i=0;
while(i<=10){
    total=total+i;
    i++;
}

console.log(total);

